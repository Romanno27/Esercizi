package esercizio;

public class Contatore implements Runnable {

	private int limit;
	
	public Contatore(int l) {
		this.limit = l;
	}
	
	public void setLimit(int l) {
		this.limit = l;
	}
	
	public int getLimit() {
		return limit;
	}
	
	@Override
	public void run() {
		for (int i = 0; i <= limit; i++) {
			String nome = Thread.currentThread().getName();
			long tid = Thread.currentThread().getId();
			System.out.printf("%5d (%5s): Sto contando %d\n", tid, nome, i);
		}

	}

}