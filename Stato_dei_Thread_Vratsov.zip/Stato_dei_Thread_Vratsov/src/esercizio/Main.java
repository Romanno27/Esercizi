package esercizio;

import java.util.Random;
import java.util.Scanner;

public class Main{

public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Inserisci il numero di Thread (T): ");
    int T = scanner.nextInt();
    System.out.print("Inserisci il limite massimo (N): ");
    int N = scanner.nextInt();
    CounterThread[] threads = new CounterThread[T];

    for (int i = 0; i < T; i++) {
        Random random = new Random();
        int X = random.nextInt(N + 1); // Genera un numero casuale tra 0 e N
        threads[i] = new CounterThread(X);
        threads[i].setName("Thread-" + (i + 1));
        threads[i].start();
    }

    int completedThreads = 0;
    while (completedThreads < T) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Stato dei Thread:");
        for (int i = 0; i < T; i++) {
            if (threads[i].isAlive()) {
                System.out.println("Thread " + threads[i].getName() + ": " + threads[i].getCount());
            } else {
                System.out.println("Thread " + threads[i].getName() + ": COMPLETO");
                completedThreads++;
            }
        }
    }

    System.out.println("TUTTI I THREAD COMPLETATI");
}
}