package esercizio;

public class CounterThread extends Thread {
    private int N;
    private int count;

    public CounterThread(int N) {
        this.N = N;
        this.count = 0;
    }

    @Override
    public void run() {
        while (count < N) {
            System.out.println("Thread " + Thread.currentThread().getName() + " : " + count);
            count++;
            try {
                Thread.sleep(120);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public int getCount() {
        return count;
    }
}
