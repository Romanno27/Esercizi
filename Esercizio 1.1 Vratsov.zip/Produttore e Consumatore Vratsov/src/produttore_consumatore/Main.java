package produttore_consumatore;

public class Main {

	public static void main(String[] args) {
		
        Buffer b = new Buffer();
        produttore p = new produttore(b); 					
        consumatore c = new consumatore(b);

        p.start(); 											
        c.start(); 											
        
    }
}
