package produttore_consumatore;

import java.util.Random;

public class produttore extends Thread implements Runnable {
	
	Random r = new Random();
	
	private int xms;
	private int num; 						
	private Buffer bp; 									
	
	public produttore(Buffer b) {
		this.bp = b;
	}
	
	@Override 
	public void run() {
				
		while(true) {
			
			num = r.nextInt(1024);       
			xms = 100 + r.nextInt(1000);
			
			try {
				
				
				String nome = Thread.currentThread().getName();
				long tid = Thread.currentThread().getId();
				
				String thread = nome + "(" + tid + ")";
				System.out.println(thread + " Genero il numero : " + num + " \n ");
				
				bp.aggiungi(num);
				System.out.println(thread + " Aggiungo il numero : " + num + " al buffer " + " \n ");

				Thread.sleep(xms);
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}		
		}
	}
}
