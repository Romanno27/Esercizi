
package produttore_consumatore;

public class Buffer {
	
    private int[] coda;
    private int capacita;
    private int dimensione;
    private int testa;
    private int fine;
	
	public Buffer() {
		this.capacita = 10 ;
		coda = new int[10];
		dimensione = 0;
    	testa = 0;
    	fine = -1;
	}
	
														//aggiungo numeri al buffer
	public synchronized void aggiungi(int numero) {
		
		while (dimensione == capacita) {
			try {
				wait(); 								//wait per quando il buffer è pieno
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}
		 												//aggiunta del numero 
        fine = (fine + 1) % capacita;
        coda[fine] = numero;
        dimensione++;
        notifyAll(); 									//sveglia i thread in wait 
        System.out.print(" Aggiunto al buffer il numero : " + numero + " \n ");
		
	}
	
														//metodo per rimuovere numeri dal buffer
	public synchronized int rimozione() {
		
		while (dimensione == 0) {
			try {
				wait(); 								//metto in attesa i thread perchè il buffer è pieno
			} catch (InterruptedException e) {
				e.printStackTrace();
			}  
		}
		
		int v = coda[testa];
        fine = (fine + 1) % capacita; 					//aggiunta del numero 
        dimensione--;
        notifyAll(); 									
		return v;
	}
}